information = [{'student':'xiaoming','age':15,'height':170},
               {'student':'xianggang','age':14,'height':168},
               {'student':'xianghong','age':15,'height':165}]

