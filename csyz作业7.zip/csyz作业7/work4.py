n = input('请输入一个大于等于三的正整数：')

number = list(range(0,10))

m = 10**(n-1)   
for a in number:
    for b in number:
        for c in number:
            if a*m+b*(m-1)+...+c == a**3 + b**3 + ...+c* :
            
            
