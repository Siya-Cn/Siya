students_list =[
    {'id':00001,'name':'huanglan','course1':78,'course2':83,'course3':75},
    {'id':00002,'name':'wanghai','course1':76,'course2':80,'course3':77},
    {'id':00003,'name':'shenqiang','course1':87,'course2':83,'course3':76},
    {'id':10001,'name':'zhangfeng','course1':92,'course2':88,'course3':78},
    {'id':21987,'name':'zhangmeng','course1':80,'course2':82,'course3':75}
    ]