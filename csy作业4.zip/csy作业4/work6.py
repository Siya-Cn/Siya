#不会
def number_check():
    print()
