number = 1
Fibonacci = [1]
while True :
    print(number)
    number = number+number
    Fibonacci.append(number)
    length = len(Fibonacci)
    
    if length == 100:
        break

#好像有点问题 不是斐波那契数列 而是等比数列

    

