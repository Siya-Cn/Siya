name=input('Please input your name: ')
print(f'\n Hello {name}')