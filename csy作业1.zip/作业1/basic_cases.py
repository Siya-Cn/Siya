message = "Python Basic"

print(message.lower())