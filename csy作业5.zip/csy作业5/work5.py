input_numbers = [10,20,10,40,50,60,70]

for a in input_numbers:
    print(a)

for b in input_numbers:
    print(b)

c = a + b
if c == 50:
    print

#没太懂题目的意思 要求两个数和为50 但是索引为3和4两个数的和为90 
# 这题到底要干嘛？？？

