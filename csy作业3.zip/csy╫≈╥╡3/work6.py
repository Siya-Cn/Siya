#这题能用循环的方式写吗？我试了下是报错
dict = {num:num**2 for num in range(1,16)}
print(dict)




