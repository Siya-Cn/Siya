goods = input('Please input the product(A/B/C): ')
off_price = int(input('Please input the off number: '))

if goods =='A' :
    if off_price >30 :
        print(f'SOS {goods} {off_price}')
if goods =='B' :
    if off_price >20 :
        print(f'SOS {goods} {off_price}')
if goods =='C' :
    if off_price >10 :
        print(f'SOS {goods} {off_price}')
    




