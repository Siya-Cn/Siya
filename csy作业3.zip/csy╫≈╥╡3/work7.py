ori_dict = {'C1':[10,20,30],'C2':[20,30,40],'C3':[12,34]}

del ori_dict['C1']
del ori_dict['C2']
del ori_dict['C3']

print(ori_dict)