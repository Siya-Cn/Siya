points = int(input('Please input your points: '))

if points < 60 :
    print('Come on!')
if points < 80 :
    print('Not bad!It is time to study hard!')
if points <= 100 :
    print('Well done!Do not be proud.')



