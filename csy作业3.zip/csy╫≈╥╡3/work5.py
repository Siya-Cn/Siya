total = [
    {'sku':'SKU-A','quantity':100},
    {'sku':'SKU-B','quantity':200},
    {'sku':'SKU-C','quantity':400},
    {'sku':'SKU-D','quantity':300}
]

#统计物件总数量我不会
#for one_quantity in total:
   # number = int(one_quantity.values())
   # sum_quantity = sum(number['quantity'])
   # print(sum_quantity)

#有没有简便方法 只想到了复杂方法
del total[0]
total.insert(0,{'sku':'SKU-A','quantity':200})
print(total)

#怎么把这个新增元素加到列表的最后一位？用-1加在了倒数第二位
total.insert(-1,{'sku':'SKU-E','quantity':300})
print(total)

del total[1]
print(total)

new_total = total[-1:]
print(new_total)